"""
URL configuration for pj project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from . import views
from home_app.views import *

urlpatterns = [
    path('',views.cust_firstpage,name='cust_firstpage'),
    path('cust_home',views.cust_home,name='cust_home'),
    path('cust_login',views.cust_login,name='cust_login'),
    path('cust_home_page',views.cust_home_page,name='cust_home_page'),
    path('cust_car_list',views.cust_car_list,name='cust_car_list'),
    path('cust_car_or_bike',views.cust_car_or_bike,name='cust_car_or_bike'),
    path('cust_bike_list',views.cust_bike_list,name='cust_bike_list'),
    path('cust_payment.html',views.cust_payment,name='cust_payment'),
    path('cust_bike_pay.html',views.cust_bike_pay,name='cust_bike_pay'),
    path('final_payment.html',views.final_payment,name='final_payment'),
    path('car_details_1.html',views.car_details_1,name='car_details_1'),






]
