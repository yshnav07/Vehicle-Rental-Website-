from django.shortcuts import render,redirect
from . models import *
# Create your views here.
def cust_firstpage(request):
    if request.method=="POST":
        cars = Car.objects.all()
        return redirect("cust_home")
    return render(request, 'cust_firstpage.html')

def cust_home(request):
    if request.method=="POST":
        firstname1=request.POST.get('firstname')
        lastname1=request.POST.get('lastname')
        address1=request.POST.get('address')
        email1=request.POST.get('email')
        password1=request.POST.get('password')
        cpassword1=request.POST.get('cpassword')
        if password1==cpassword1:
            data=Registration(firstname=firstname1,lastname=lastname1,address=address1,email=email1,password=password1,cpassword=cpassword1)
            data.save()
        return redirect('cust_home_page')
    return render(request,'cust_home.html')

def cust_login(request):
    if request.method=="POST":
        email2=request.POST.get('email')
        password2=request.POST.get('password')
        
        return redirect('cust_home_page')
    return render(request,'cust_login.html')

def cust_home_page(request):
    return render(request,'cust_home_page.html')

def cust_car_or_bike(request):
    return render(request,'cust_car_or_bike.html')

def cust_car_list(request):
    return render(request,'cust_car_list.html')

def cust_bike_list(request):
    return render(request,'cust_bike_list.html')

def cust_payment(request):
    return render(request,'cust_payment.html')

def cust_bike_pay(request):
    return render(request,'cust_bike_pay.html')

def final_payment(request):
    return render(request,'final_payment.html')

def car_details_1(request):
    return render(request,'car_details_1.html')




